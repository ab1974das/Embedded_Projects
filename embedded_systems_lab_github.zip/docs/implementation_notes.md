# Implementation Notes and Source Fidelity

These files are organized from the supplied six-page lab report. Where the report supplied only a snippet or algorithm description, the repository labels the missing implementation honestly rather than claiming it was tested.

## Sine-wave/FIR project

- The report's stated signal is `0.1 sin(2πf1t) + 0.05 sin(2πf2t) + 0.1`, with `f1 = 1 Hz` and `f2 = 30 Hz`.
- The report's MATLAB example later omits amplitudes and DC offset. The MATLAB file in this repository follows the stated objective.
- The report uses `t = 0:1/2048:1`, which produces 2049 points including both endpoints. This repository uses 2048 points over `[0,1)` to avoid duplicating the endpoint.
- The report's DAC conversion formula is preserved: `((x+2)/4)*255`. This is the formula described in the report, although the stated signal occupies a much smaller range than the full DAC range.
- The specified coefficients are preserved. Their Q8 integer values are `10, 30, 20, 32, 34, 36, 34, 32, 20, 30, 10`.
- The PDF describes retaining the current and previous ten samples and using `MUL`, but does not include a complete FIR assembly routine. The assembly file marks this as a scaffold.
- The sample playback loop needs a proper table pointer and timer interrupt for reliable continuous playback. The short delay is illustrative only.

## UART bit counter

The assembly follows the report's UART receive, bit counting, PORTC display, and ASCII reply flow. It includes a reset vector and writes `UBRRH = 0`, making the baud-rate setting explicit. Verify the MCU datasheet, clock fuse settings, and serial wiring on the target board.

## Suggested GitHub description

Embedded Systems Lab projects in AVR assembly: 8-bit DAC sine-wave lookup-table generation, FIR low-pass filter coefficient conversion, and UART received-byte population counting.
