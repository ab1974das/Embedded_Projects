# UART Bit Counter

Receives one byte through UART, counts the number of set bits (ones), displays the count in binary on `PORTC`, and sends the count as an ASCII digit (`'0'` through `'8'`) back through UART.

## Configuration from the report

- MCU/include file: ATmega32 / `M32DEF.INC`
- CPU clock assumption: 8 MHz
- Baud rate: 9600
- Frame: 8 data bits, 1 stop bit (8N1)
- LEDs: `PORTC`

## Build and run

1. Assemble `avr/uart_bit_counter.asm` using an AVR assembler that supports `M32DEF.INC` syntax.
2. Program the ATmega32.
3. Open a serial terminal at 9600 baud, 8N1.
4. Send a character/byte. The PORTC LEDs display the count as a binary number, and the serial terminal receives the ASCII digit for the number of ones.

Example: input byte `00001111` has four set bits, so the output character is `4`.
