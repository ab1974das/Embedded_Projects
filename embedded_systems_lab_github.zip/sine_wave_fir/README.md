# Sine-Wave Generator and 10th-Order FIR Low-Pass Filter

## Objective

Generate the signal

`x(t) = 0.1 sin(2π·1·t) + 0.05 sin(2π·30·t) + 0.1`

in MATLAB, convert it to 8-bit DAC codes, and send samples to an external DAC using an AVR microcontroller. The 11-tap FIR low-pass filter uses the coefficients listed below to pass the 1 Hz component and attenuate the 30 Hz component.

## Specifications from the report

| Parameter | Value |
|---|---|
| Signal component frequencies | 1 Hz and 30 Hz |
| Nominal sampling frequency in statement | 100 Hz |
| Lookup table | 2048 points over 1 s |
| DAC code | 8-bit unsigned, 0–255 |
| FIR order | 10 |
| FIR taps | 11 |

**Sampling-rate note:** A 2048-entry table traversed once per second needs a 2048 Hz update rate, not 100 Hz. For 100 Hz output, use 100 samples/s or implement an appropriate sample-selection/timing scheme.

## Files

- `matlab/generate_lookup_table.m` generates the sample codes and an AVR `.DB` table include.
- `avr/sine_wave_fir.asm` is an ATmega32-style assembly template for DAC output and FIR filtering.

## FIR coefficients

```text
0.0391, 0.1172, 0.0781, 0.1250, 0.1328, 0.1406,
0.1328, 0.1250, 0.0781, 0.1172, 0.0391
```

Q8 integer coefficients (`round(h*256)`):

```text
10, 30, 20, 32, 34, 36, 34, 32, 20, 30, 10
```

The report uses `M32DEF.INC`, which suggests ATmega32. Check pin mapping before connecting the DAC; on common ATmega32 variants PORTC pins may also be used for JTAG.
