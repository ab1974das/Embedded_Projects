# AVR files

`sine_wave_fir.asm` records the ATmega32-style setup, DAC output path, history-buffer allocation, FIR coefficient table, and a clearly marked FIR scaffold.

**Important:** The supplied PDF only contains a short lookup-table playback snippet and a description of the FIR algorithm; it does not contain a complete FIR assembly implementation. The FIR routine is therefore explicitly marked as a scaffold rather than represented as fully tested code. Generate the lookup table with the MATLAB script and complete/verify continuous table playback and timer-based sample timing for your hardware.
