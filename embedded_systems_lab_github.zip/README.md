# Embedded Systems Lab Projects

**Author:** Abhirup Das (22IE34003)  
**Course:** Embedded Systems Lab

This repository contains two AVR assembly projects based on the supplied lab report:

1. **Sine-Wave Generator and 10th-Order FIR Low-Pass Filter**
2. **UART Bit Counter**

## Repository structure

```text
.
├── sine_wave_fir/
│   ├── matlab/
│   │   └── generate_lookup_table.m
│   ├── avr/
│   │   ├── sine_wave_fir.asm
│   │   └── README.md
│   └── README.md
├── uart_bit_counter/
│   ├── avr/
│   │   └── uart_bit_counter.asm
│   └── README.md
└── docs/
    └── implementation_notes.md
```

## Requirements

- MATLAB (for generating the DAC lookup table)
- AVR assembler/toolchain compatible with ATmega32 assembly
- ATmega32 or a compatible target
- External 8-bit DAC wired to `PORTC` for the waveform project
- UART serial terminal configured to **9600 baud, 8 data bits, no parity, 1 stop bit (9600 8N1)** for the UART project

## Important implementation notes

- The supplied report gives a 2048-point table over one second, which implies a table update rate of 2048 samples/s when read sequentially. This differs from the separately specified 100 Hz sampling frequency.
- The report's FIR coefficients are included as provided. They sum to 1.0001 due to rounding.
- The report describes the FIR algorithm but does not provide a complete working FIR assembly routine or a complete waveform lookup table. The AVR file therefore includes a reusable FIR routine and a placeholder table region; generate the table with the MATLAB script before building.
- The report's original MATLAB snippets differ in places from the stated target signal. The supplied MATLAB script uses the stated signal:
  `x(t) = 0.1 sin(2π·1·t) + 0.05 sin(2π·30·t) + 0.1`
- Verify the target MCU's datasheet and assembler syntax before programming hardware.

## Projects

- [Sine wave + FIR project](sine_wave_fir/README.md)
- [UART bit counter project](uart_bit_counter/README.md)
- [Implementation notes](docs/implementation_notes.md)
